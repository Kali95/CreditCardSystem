package Runner;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws SQLException{
        System.out.println("Welcome to Credit Management System Menu: ");
        
        
        
        
        System.out.println("Enter 1 for customer details");
        System.out.println("Enter 2 for transaction details");
        System.out.println("Please choose an option");
        Scanner Input = new Scanner(System.in);
        int userInput = Input.nextInt();
        switch (userInput) {
		case 1:
			CustomerRunner.main(null);
			break;
		case 2:
			TransactionRunner.main(null);
			break;
        }
    }
}




