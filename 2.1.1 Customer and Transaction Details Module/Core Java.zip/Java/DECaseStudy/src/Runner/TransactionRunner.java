package Runner;

import DAO.*;
import java.sql.SQLException;
import java.util.Scanner;

public class TransactionRunner {

    public static void main(String[] args)throws SQLException {
        System.out.println("You entered the transaction details system");
        System.out.println("Enter 1 to display the transaction for a month and year");
        System.out.println("Enter 2 to display the number and total value of transactions for a given type");
        System.out.println("Enter 3 to display the number and total value of transactions for branches in a given state");
        System.out.println("Please choose an option");
        Scanner Input = new Scanner(System.in);
        int input_customer = Input.nextInt();
        switch (input_customer) {
		case 1:
            TransactionDaoImp t1 = new TransactionDaoImp();
            Scanner Trans = new Scanner(System.in);
            System.out.println("Please enter your social security number: ");
            int ssn_1 = Input.nextInt();
            if(!t1.checkSSN(ssn_1).next()){
                System.out.println("The database don't records for you Social Security Number\nPlease check your SSN");
            }
            else{
                System.out.println("Please enter your zipcode: ");
                String zip_code = Trans.nextLine();
                System.out.println("Please enter your month: ");
                int month  = Input.nextInt();
                System.out.println("Please enter your year: ");
                int year = Input.nextInt();
                t1.getTransactionByZipcode(zip_code, month, year,ssn_1);
            }
            break;
		case 2:
            TransactionDaoImp t2 = new TransactionDaoImp();
            Scanner Trans2 = new Scanner(System.in);
            System.out.println("Please enter a transaction type: ");
            String transaction_type = Trans2.nextLine();
            if(!t2.checkType(transaction_type).next()){
                System.out.println("The database don't have transaction number and value for the input type "+ "'"+transaction_type+"'");
            }
            else{
                t2.TransactionNumberAndValue(transaction_type);
            }
            break;
		case 3:
            TransactionDaoImp t3 = new TransactionDaoImp();
            Scanner Trans3 = new Scanner(System.in);
            System.out.println("Please enter a state name: ");
            String state = Trans3.nextLine();
            if(!t3.checkState(state).next()){
                System.out.println("The database don't have transaction number and value for the input state " + "'"+state.toUpperCase()+"'");
            }
            else{
                t3.getTransactionByState(state);
            }
            break;
        }

    }

}
