package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


public class TransactionDaoImp implements TransactionDao {

    public TransactionDaoImp() {
        super();

    }
    private Connection myConn = null;
    private ResultSet myRs = null;

    @Override
    public void getTransactionByZipcode(String Zip_code, int month, int year, int ssn) throws SQLException {

        String sql = String.format(MyQuery.getTransactionByZipCode, Zip_code, month, year, ssn);

        ConnectionDB t1 = new ConnectionDB();

        Connection myConn = t1.getConnection();
        ResultSet myRs = t1.executeSQL(sql);

        if( !myRs.next()){
            System.out.println("The database don't transaction detail for the input month and year");
        }
        while (myRs.next()) {
            System.out.println("             " + myRs.getString("first_name") + " " +
                    myRs.getString("middle_name") + " " + myRs.getString("last_name") + " " +
                    myRs.getInt("ssn") + " " + myRs.getString("credit_card_no") + " " +
                    myRs.getString("apt_no") + " " + myRs.getString("street_name") + " " +
                    myRs.getString("cust_city") + " " + myRs.getString("cust_state") + " " +
                    myRs.getString("cust_country") + " " + myRs.getString("cust_zip") + " " + myRs.getInt("cust_phone") + " " +
                    myRs.getString("cust_email") + " " + myRs.getTimestamp("last_updated") + " " +
                    myRs.getInt("transaction_id") + " " + myRs.getInt("day") + " " + myRs.getInt("month") + " " +
                    myRs.getInt("year") + " " + myRs.getString("credit_card_no") + " " + myRs.getInt("branch_code") + " " +
                    myRs.getString("Transaction_type") + " " + myRs.getBigDecimal("transaction_value"));

        }

        t1.closeConnection(myConn, myRs);


    }

    @Override
    public void TransactionNumberAndValue(String transaction_type) throws SQLException {

        String sql2 = String.format(MyQuery.getTransactionType, transaction_type);
        ConnectionDB t2 = new ConnectionDB();

        Connection myConn = t2.getConnection();
        ResultSet myRs = t2.executeSQL(sql2);

        while(myRs.next()){

            System.out.println("The result is : Number Total_Value");
            System.out.println("                 " + myRs.getString("Number_of_Transactions") + " " +
                    myRs.getInt("Total_Value"));
            t2.closeConnection(myConn, myRs);

        }
    }


    @Override
    public void getTransactionByState(String state) throws SQLException {

        String sql3 = String.format(MyQuery.getTransactionByState, state);

        ConnectionDB t3 = new ConnectionDB();

        Connection myConn3 = t3.getConnection();
        ResultSet myRs3 = t3.executeSQL(sql3);

        System.out.println("The result is : Number Total_Value");
        while (myRs3.next()) {
            System.out.println("                 " + myRs3.getString("Number_of_Transactions") + " " +
                    myRs3.getInt("Total_Value"));

        }
        t3.closeConnection(myConn3,myRs3);
    }

    public ResultSet checkSSN(int ssn) throws SQLException{

        String sql = String.format(MyQuery.checkSSN,ssn);
        ConnectionDB t4 = new ConnectionDB();

        myRs = t4.getConnectionToCheckSSN(sql);
        return myRs;

    }

    public ResultSet checkType(String string) throws SQLException{

        String sql = String.format(MyQuery.checkType,string);
        ConnectionDB t5 = new ConnectionDB();

        myRs = t5.getConnectionToCheckSSN(sql);
        return myRs;

    }

    public ResultSet checkState(String string) throws SQLException{

        String sql = String.format(MyQuery.checkState,string);
        ConnectionDB t6 = new ConnectionDB();

        myRs = t6.getConnectionToCheckSSN(sql);
        return myRs;

    }

}
