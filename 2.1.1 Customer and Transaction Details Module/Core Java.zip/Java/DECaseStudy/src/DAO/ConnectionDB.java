package DAO;

import java.sql.*;

public class ConnectionDB {
    private Connection myConn = null;
    private Statement myStmt = null;
    private ResultSet myRs = null;

    private String dbUrl = "jdbc:mysql://localhost:3306/cdw_sapp";
    private String user = "root";
    private String pass = "mysql"; 


    public Connection getConnection() throws SQLException{

        myConn = DriverManager.getConnection(dbUrl, user, pass);

        System.out.println("Connecting to the database..........\nDatabase connection successful!\n");

        return myConn;

    }

    public ResultSet getConnectionToCheckSSN(String sql) throws SQLException{

        myConn = DriverManager.getConnection(dbUrl, user, pass);
        myStmt = myConn.createStatement();
        myRs = myStmt.executeQuery(sql);
        return myRs;

    }

    public ResultSet executeSQL(String sql) throws SQLException{

        myStmt = myConn.createStatement();

        System.out.println("Executing your command............\nplease hold>>>>>>>>>>\n");
        myRs = myStmt.executeQuery(sql);

        return myRs;
        }

    public ResultSet updateSQL(String sql1, String sql2) throws SQLException{

        myStmt = myConn.createStatement();

        System.out.println("Updating the databse........\n");
        int Rows = myStmt.executeUpdate(sql1);
        ResultSet myRs_2 = myStmt.executeQuery(sql2);

        return myRs_2;
    }

    public void closeConnection(Connection myConn, ResultSet myRs)throws SQLException{

        if(myRs.next()){
                if (myConn != null) {
                    myConn.close();
                }
            }

    }
}
